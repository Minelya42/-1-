----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 23.02.2026 21:27:43
-- Design Name: 
-- Module Name: zalgau1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.all;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity zalgau1 is
    Port  ( x1 : in STD_LOGIC;
           x2 : in STD_LOGIC;
           x3 : in STD_LOGIC;
           x4 : in STD_LOGIC;
           y1 : out STD_LOGIC;
           y2 : out STD_LOGIC;
           y3 : out STD_LOGIC;
           y4 : out STD_LOGIC;
           y5 : out STD_LOGIC);
end zalgau1;

architecture Behavioral of zalgau1 is
component N     port ( A : in STD_LOGIC; Y : out STD_LOGIC ); end component;
    component NO2   port ( A, B : in STD_LOGIC; Y : out STD_LOGIC ); end component;
    component O3    port ( A, B, C : in STD_LOGIC; Y : out STD_LOGIC ); end component;
    component NOA22 port ( A, B, C, D : in STD_LOGIC; Y : out STD_LOGIC ); end component;
    component NAOA2 port ( A, B, C, D : in STD_LOGIC; Y : out STD_LOGIC ); end component;
    component NOA3  port ( A, B, C, D : in STD_LOGIC; Y : out STD_LOGIC ); end component;
    component GND   port ( Y : out STD_LOGIC ); end component;

    -- ������������� ������� (��� ������)
    -- 1-�� ��?�� ����������
    signal s_c1_n1_y    : STD_LOGIC;

    -- 2-�� ��?�� ����������
    signal s_c2_no2_1_y : STD_LOGIC;
    signal s_c2_no2_2_y : STD_LOGIC;
    signal s_c2_n1_y    : STD_LOGIC;

    -- 3-�� ��?�� ����������
    signal s_c3_n1_y    : STD_LOGIC;
    signal s_c3_o3_y    : STD_LOGIC;
    signal s_c3_noa22_y : STD_LOGIC;
    signal s_c3_n2_y    : STD_LOGIC;
    signal s_c3_n3_y    : STD_LOGIC;
    signal s_c3_n4_y    : STD_LOGIC;
    
    attribute KEEP : string;
    attribute DONT_TOUCH : string;
    
    attribute KEEP of s_c1_n1_y, s_c2_no2_1_y, s_c2_no2_2_y, s_c2_n1_y, s_c3_n1_y, s_c3_o3_y, s_c3_noa22_y, s_c3_n2_y, s_c3_n3_y, s_c3_n4_y : signal is "TRUE";
    attribute DONT_TOUCH of Behavioral : architecture is "TRUE";
begin
-- 1-bagan
U_C1_N1 : N port map ( A => x1, Y => s_c1_n1_y );
-- 2-bagan
U_C2_NO2_1 : NO2 port map ( A => x2, B => s_c1_n1_y, Y => s_c2_no2_1_y );
    U_C2_NO2_2 : NO2 port map ( A => x3, B => x1,        Y => s_c2_no2_2_y );
    U_C2_N1    : N   port map ( A => x3,                 Y => s_c2_n1_y );
-- 3-bagan
U_C3_N1    : N     port map ( A => s_c1_n1_y, Y => s_c3_n1_y );
    U_C3_O3    : O3    port map ( A => s_c1_n1_y, B => x1, C => x2, Y => s_c3_o3_y );
    U_C3_NOA22 : NOA22 port map ( A => x3, B => s_c2_no2_2_y, C => x2, D => s_c2_no2_1_y, Y => s_c3_noa22_y );
    U_C3_N2    : N     port map ( A => x2, Y => s_c3_n2_y );
    U_C3_N3    : N     port map ( A => x4, Y => s_c3_n3_y );
    U_C3_N4    : N     port map ( A => x3, Y => s_c3_n4_y );
-- 4-bagan
U_C4_NAOA2_1 : NAOA2 port map ( A => s_c3_o3_y, B => x3, C => s_c3_n1_y, D => x1, Y => y1 );
U_C4_NAOA2_2 : NAOA2 port map ( A => s_c3_noa22_y, B => x1, C => s_c3_n2_y, D => x1, Y => y5 );
    
    U_C4_NOA3    : NOA3  port map ( A => s_c3_n3_y, B => x1, C => s_c3_n4_y, D => x2, Y => y2 );
    
    U_C4_GND     : GND   port map ( Y => y3 );
    
    U_C4_NO2     : NO2   port map ( A => x4, B => s_c3_n4_y, Y => y4 );
end Behavioral;
