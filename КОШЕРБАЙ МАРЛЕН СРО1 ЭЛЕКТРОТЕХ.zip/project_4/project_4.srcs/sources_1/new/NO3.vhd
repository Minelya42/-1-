library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NO3 is
    Port ( A, B, C : in STD_LOGIC;
           Y : out STD_LOGIC);
end NO3;

architecture Behavioral of NO3 is
begin
    Y <= not ((A or B or c ) );
end Behavioral;