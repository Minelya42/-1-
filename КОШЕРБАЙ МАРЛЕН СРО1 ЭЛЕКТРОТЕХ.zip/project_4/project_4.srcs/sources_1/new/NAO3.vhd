library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NAO3 is
    Port ( A, B, C, D : in STD_LOGIC;
           Y : out STD_LOGIC);
end NAO3;

architecture Behavioral of NAO3 is
begin
    Y <= not ((A and (B or c or d)) );
end Behavioral;