library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NOA2 is
    Port ( A, B, C : in STD_LOGIC;
           Y : out STD_LOGIC);
end NOA2;

architecture Behavioral of NOA2 is
begin
    Y <= not (A and (B or c ) );
end Behavioral;