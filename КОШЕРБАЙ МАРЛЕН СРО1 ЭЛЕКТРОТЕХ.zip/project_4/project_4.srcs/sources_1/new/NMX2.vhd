library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NMX2 is
    Port ( A, B, V : in STD_LOGIC;
           Y : out STD_LOGIC);
end NMX2;

architecture Behavioral of NMX2 is
begin
    Y <= not ((A or not V) and (B or V) );
end Behavioral;