library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity finish is
    Port ( x1, x2, x3, x4 : in  STD_LOGIC;
           y1, y2, y3, y4 : out STD_LOGIC);
end finish;

architecture Structural of finish is

    signal n_1,n_2,n_3,noa2_4,nmx2_5,n_6,n_7,n_8,no3_9,na2_10,n_11,na3_12,na3o2_13,nao22_14,nao3_15,n_16 : STD_LOGIC;

    component N
    Port ( A : in STD_LOGIC;
           Y : out STD_LOGIC);
end component;

component NA2
    Port ( A, B : in STD_LOGIC;
           Y    : out STD_LOGIC);
end component;

component NOA2
    Port ( A, B, C : in STD_LOGIC;
           Y       : out STD_LOGIC);
end component;

component NA3O2
    Port ( A, B, C, D : in STD_LOGIC;
           Y          : out STD_LOGIC);
end component;

component NAO22
    Port ( A, B,c,d : in STD_LOGIC;
           Y    : out STD_LOGIC);
end component;

component NMX2
    Port ( A, B, V : in STD_LOGIC;
           Y          : out STD_LOGIC);
end component;

component NAO3
    Port ( A, B, C, D : in STD_LOGIC;
           Y          : out STD_LOGIC);
end component;

component NA3
    Port ( A, B, C : in STD_LOGIC;
           Y          : out STD_LOGIC);
end component;

component NAO2
    Port ( A, B, C : in STD_LOGIC;
           Y       : out STD_LOGIC);
end component;

component NO3
    Port ( A, B, C : in STD_LOGIC;
           Y          : out STD_LOGIC);
end component;

begin
    
    N1:N port map(x3,n_1);
    N2:N port map(nao3_15,n_2);
    N3:N port map(n_2,n_3);
    NOA2_44:NOA2 port map(x1,n_1,x2,noa2_4);
    NMX2_55:NMX2 port map(n_1,x1,x2,nmx2_5);
    N6:N port map(x1,n_6);
    N7:N PORT MAP(n_16, n_7);
    N8:N port map(x2,n_8);
    NO3_99:NO3 port map(noa2_4,x4,n_3,no3_9);
    NA2_100:NA2 port map(x1, n_8, na2_10);
    N11:N port map(n_2,n_11);
    NA3_122:NA3 port map(nmx2_5,x4,n_7,na3_12);
    NA3O2_133:NA3O2 port map(x3,n_6,na2_10,x4,na3o2_13);
    NAO22_144:NAO22 port map(x3,n_11,no3_9,na2_10,nao22_14);
    NAO3_155:NAO3 port map(na3_12,n_6,x3,x4, nao3_15);
    N16:N port map(na3o2_13,n_16);
    y1<=no3_9;
    y2<=n_16;
    y3<=nao3_15;
    y4<=nao22_14;
    
    
    

end Structural;