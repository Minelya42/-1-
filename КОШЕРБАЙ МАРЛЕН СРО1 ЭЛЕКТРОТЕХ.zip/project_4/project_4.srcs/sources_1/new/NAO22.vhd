library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NAO22 is
    Port ( A, B, C, D : in STD_LOGIC;
           Y : out STD_LOGIC);
end NAO22;

architecture Behavioral of NAO22 is
begin
    Y <= not (((A or B) and (c or d)) );
end Behavioral;