library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NA3 is
    Port ( A, B, C : in STD_LOGIC;
           Y : out STD_LOGIC);
end NA3;

architecture Beshavioral of NA3 is
begin
    Y <= not (A and B and C);
end Beshavioral;