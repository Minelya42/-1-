library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NA2 is
    Port ( A, B: in STD_LOGIC;
           Y : out STD_LOGIC);
end NA2;

architecture Behavioral of NA2 is
begin
    Y <= not (A and B );
end Behavioral;