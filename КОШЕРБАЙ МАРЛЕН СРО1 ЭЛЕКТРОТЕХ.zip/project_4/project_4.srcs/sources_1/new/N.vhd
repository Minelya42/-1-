library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity N is
    Port (a: in STD_LOGIC;
          y: out STD_LOGIC);
end N;
architecture Behavioral of N is
begin
    Y <= not A;
end Behavioral;