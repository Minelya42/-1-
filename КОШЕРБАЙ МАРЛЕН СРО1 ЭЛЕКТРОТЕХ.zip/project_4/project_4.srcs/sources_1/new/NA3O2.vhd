library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity NA3O2 is
    Port ( A, B, C, D : in STD_LOGIC;
           Y : out STD_LOGIC);
end NA3O2;

architecture Behavioral of NA3O2 is
begin
    Y <= not ((A and B and (c or d)) );
end Behavioral;